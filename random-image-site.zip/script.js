(function () {
  var frame = document.getElementById("frame");
  var photo = document.getElementById("photo");
  var errorBox = document.getElementById("error");
  var toast = document.getElementById("toast");
  var regen = document.getElementById("regen");
  var toastTimer = null;
  var currentSeed = "";
  var currentBlob = null;

  function makeSeed() {
    var chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    var out = "";
    for (var i = 0; i < 10; i++) {
      out += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return out;
  }

  function imageUrl(seed) {
    return "https://picsum.photos/seed/" + encodeURIComponent(seed) + "/1200/900";
  }

  function pageUrl() {
    return window.location.origin + window.location.pathname + "?seed=" + encodeURIComponent(currentSeed);
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.remove("show");
    }, 2600);
  }

  function prefetchBlob(url, seed) {
    currentBlob = null;
    fetch(url, { mode: "cors" })
      .then(function (res) {
        if (!res.ok) {
          throw new Error("bad response");
        }
        return res.blob();
      })
      .then(function (blob) {
        if (seed === currentSeed) {
          currentBlob = blob;
        }
      })
      .catch(function () {
        currentBlob = null;
      });
  }

  function loadImage(seed) {
    currentSeed = seed;
    var url = imageUrl(seed);
    frame.classList.add("loading");
    photo.classList.remove("ready");
    errorBox.hidden = true;
    regen.disabled = true;

    var loader = new Image();
    loader.onload = function () {
      if (seed !== currentSeed) {
        return;
      }
      photo.src = url;
      photo.classList.add("ready");
      frame.classList.remove("loading");
      regen.disabled = false;
      prefetchBlob(url, seed);
    };
    loader.onerror = function () {
      if (seed !== currentSeed) {
        return;
      }
      frame.classList.remove("loading");
      errorBox.hidden = false;
      regen.disabled = false;
    };
    loader.src = url;

    var next = window.location.pathname + "?seed=" + encodeURIComponent(seed);
    try {
      window.history.replaceState(null, "", next);
    } catch (e) {}
  }

  function newImage() {
    loadImage(makeSeed());
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      var area = document.createElement("textarea");
      area.value = text;
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.select();
      var ok = false;
      try {
        ok = document.execCommand("copy");
      } catch (e) {}
      document.body.removeChild(area);
      if (ok) {
        resolve();
      } else {
        reject(new Error("copy failed"));
      }
    });
  }

  function openWindow(url) {
    var w = window.open(url, "_blank", "noopener");
    if (!w) {
      window.location.href = url;
    }
  }

  function shareWhatsapp() {
    var text = "Check out this random image: " + pageUrl();
    openWindow("https://wa.me/?text=" + encodeURIComponent(text));
  }

  function shareFacebook() {
    openWindow("https://www.facebook.com/sharer/sharer.php?u=" + encodeURIComponent(pageUrl()));
  }

  function shareToApp(appName, fallbackUrl) {
    var link = pageUrl();
    if (currentBlob && navigator.share && navigator.canShare) {
      var file = new File([currentBlob], "random-image.jpg", { type: currentBlob.type || "image/jpeg" });
      if (navigator.canShare({ files: [file] })) {
        navigator
          .share({ files: [file], title: "Random image", text: link })
          .catch(function (err) {
            if (err && err.name === "AbortError") {
              return;
            }
            fallbackShare(appName, fallbackUrl, link);
          });
        return;
      }
    }
    fallbackShare(appName, fallbackUrl, link);
  }

  function fallbackShare(appName, fallbackUrl, link) {
    copyText(link)
      .then(function () {
        showToast("Link copied. Paste it in " + appName + ".");
      })
      .catch(function () {
        showToast("Open " + appName + " and paste: " + link);
      })
      .then(function () {
        setTimeout(function () {
          openWindow(fallbackUrl);
        }, 700);
      });
  }

  function copyLink() {
    copyText(pageUrl())
      .then(function () {
        showToast("Link copied. It opens this same image.");
      })
      .catch(function () {
        showToast("Could not copy. Copy the address bar instead.");
      });
  }

  document.getElementById("regen").addEventListener("click", newImage);
  document.getElementById("shareWhatsapp").addEventListener("click", shareWhatsapp);
  document.getElementById("shareFacebook").addEventListener("click", shareFacebook);
  document.getElementById("shareInstagram").addEventListener("click", function () {
    shareToApp("Instagram", "https://www.instagram.com/");
  });
  document.getElementById("shareTiktok").addEventListener("click", function () {
    shareToApp("TikTok", "https://www.tiktok.com/");
  });
  document.getElementById("copyLink").addEventListener("click", copyLink);

  var params = new URLSearchParams(window.location.search);
  var incoming = params.get("seed");
  if (incoming && /^[A-Za-z0-9_-]{1,40}$/.test(incoming)) {
    loadImage(incoming);
  } else {
    newImage();
  }
})();
